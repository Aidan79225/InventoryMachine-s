package com.aidan.secondinventoryworkplatform;

import android.app.Fragment;

/**
 * Created by s352431 on 2016/11/22.
 */
public interface BaseFragmentManager{
    void loadFragment(Fragment fragment);
}
