package com.aidan.secondinventoryworkplatform;

/**
 * Created by Aidan on 2017/8/27.
 */

public class SettingConstants {
    public static final String  SETTING_CAMERA = "SETTING_CAMERA";
    public static final String CAMERA_IS_OPEN = "CAMERA_IS_OPEN";
}
