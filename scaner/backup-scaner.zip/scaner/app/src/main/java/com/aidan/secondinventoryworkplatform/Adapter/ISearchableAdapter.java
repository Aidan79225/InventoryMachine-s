package com.aidan.secondinventoryworkplatform.Adapter;

/**
 * Created by Aidan on 2017/3/30.
 */

public interface ISearchableAdapter {
    void search(String key);
    void stopSearch();
}
