package com.aidan.secondinventoryworkplatform;

/**
 * Created by Aidan on 2017/3/30.
 */

public class KeyConstants {
    public static final String data = "DATA";
    public static final String isLogin = "isLogin";
    public static final String[] IMEIS = {
//            "353025075956037",
//            "355693062107266",
            "357640060110055",
            "359409070925248",
            "359409070923255",
            "353025075956037",
            "359409070923248",
            "352842061132212",
            "357640060110055",
            "357579080044789",
            "357579080044359",
            "357579080064357"
    };
    //---------------大標籤----------------------------------//
    public static final String AuthorityName = "臺灣臺北地方法院檢察署";       //臺灣臺北地方法院檢察署
    public static final String ItemName = "";                                 //非消耗物品
    //---------------小標籤----------------------------------//
    public static final String LittleAuthorityName = "臺北地檢署";       //臺灣臺北地方法院檢察署
    public static final String LittleItemName = "非消耗物品";                                 //非消耗物品

    public static final boolean showPrint = true;   //true 顯示列印   false 不顯示列印
//    public static final String key = "sin239593931016alice0215";
    public static final String key = "1";


}
