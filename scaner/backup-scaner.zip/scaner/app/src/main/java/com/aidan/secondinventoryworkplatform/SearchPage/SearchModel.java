package com.aidan.secondinventoryworkplatform.SearchPage;

/**
 * Created by Aidan on 2017/1/8.
 */

public class SearchModel {
}
