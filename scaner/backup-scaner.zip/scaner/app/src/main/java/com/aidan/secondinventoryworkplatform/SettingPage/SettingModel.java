package com.aidan.secondinventoryworkplatform.SettingPage;

/**
 * Created by Aidan on 2017/1/8.
 */

public class SettingModel {
}
