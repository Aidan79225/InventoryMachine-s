package com.aidan.secondinventoryworkplatform.Dialog;

/**
 * Created by Aidan on 2017/3/30.
 */

public interface SearchableItem {
    String getName();
}
