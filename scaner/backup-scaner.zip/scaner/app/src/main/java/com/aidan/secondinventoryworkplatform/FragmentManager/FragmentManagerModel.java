package com.aidan.secondinventoryworkplatform.FragmentManager;

/**
 * Created by Aidan on 2016/10/25.
 */

public class FragmentManagerModel {
}
