package com.aidan.secondinventoryworkplatform.Entity;

/**
 * Created by Aidan on 2016/10/24.
 */

public class ItemConstants {
    public static final String PA3C1 = "PA3C1";
    public static final String PA3C2 = "PA3C2";
    public static final String PA3C3 = "PA3C3";
    public static final String PA3C4 = "PA3C4";
    public static final String PA3C5 = "PA3C5";
    public static final String PA3C6 = "PA3C6";
    public static final String PA3P3 = "PA3P3";
    public static final String PA3PS = "PA3PS";
    public static final String PA3MK = "PA3MK";
    public static final String PA3BD = "PA3BD";
    public static final String PA3PY = "PA3PY";
    public static final String PA3LOC = "PA3LOC";
    public static final String PA3LOCN = "PA3LOCN";
    public static final String PA3OUT = "PA3OUT";
    public static final String PA3OUTN = "PA3OUTN";
    public static final String PA3OU = "PA3OU";
    public static final String PA3OUN = "PA3OUN";
    public static final String PA3UUT = "PA3UUT";
    public static final String PA3UUTN = "PA3UUTN";
    public static final String PA3UR = "PA3UR";
    public static final String PA3URN = "PA3URN";
    public static final String PA308 = "PA308";
    public static final String PA3DEL = "PA3DEL";
    public static final String PA3PRN = "PA3PRN";
    public static final String NAME = "NAME";

    public static final String PA3INX = "PA3INX";
    public static final String PA3C0 = "PA3C0";
    public static final String PA3C7 = "PA3C7";
    public static final String PA3QY = "PA3QY";
    public static final String PA3UNP = "PA3UNP";
    public static final String PA3TOP = "PA3TOP";
    public static final String PA3MEMO = "PA3MEMO";
    public static final String PA3MOC8 = "PA3MOC8";
    public static final String PA3MOB = "PA3MOB";

    public static final String PA3MOD = "PA3MOD";
    public static final String PA3MONO = "PA3MONO";
    public static final String PA3DED = "PA3DED";
    public static final String PA3DENO = "PA3DENO";
    public static final String PA3TI = "PA3TI";
    public static final String PA3VWW = "PA3VWW";
    public static final String PA3VN = "PA3VN";
    public static final String PA3DR = "PA3DR";
    public static final String PA3PD = "PA3PD";
    public static final String PA3AN = "PA3AN";
    public static final String PA3MOL = "PA3MOL";
    public static final String PA8PD = "PA8PD";
    public static final String PA8A = "PA8A";
    public static final String ITEM = "ITEM";
    public static final String TYPE = "TYPE";
    public static final String PA3MB = "PA3MB";

}
