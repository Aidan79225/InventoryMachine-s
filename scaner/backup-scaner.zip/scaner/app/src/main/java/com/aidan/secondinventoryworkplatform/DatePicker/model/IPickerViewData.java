package com.aidan.secondinventoryworkplatform.DatePicker.model;

/**
 * Created by Sai on 2016/7/13.
 */
public interface IPickerViewData {
    String getPickerViewText();
}
