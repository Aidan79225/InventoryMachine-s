package com.aidan.secondinventoryworkplatform.DatePicker.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
